const { sequelize, Sequelize } = require("../db")
const jsonfile = require("jsonfile")

const goldSchema = sequelize.define("Gold", {
    id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        primaryKey: true,
        autoIncrement: true
    },
    date: {
        type: Sequelize.STRING,
        allowNull: false,
        unique: true
    },
    price: {
        type: Sequelize.DOUBLE,
        allowNull: false
    }
}, {
    timestamps: false
})

// let goldJSON = jsonfile.readFileSync("../sql/gold.json")
// async function loadGoldData() {
//     for (var i = 0; i < goldJSON.length; i++) {
//         var dateInsert = goldJSON[i].date,
//             priceInsert = goldJSON[i].price
//         await goldSchema.queryInterface.bulkInsert('gold', [{
//             date: dateInsert,
//             price: priceInsert
//         }], { ignoreDuplicates: true })
//     }
// }
// loadGoldData()

module.exports = { goldSchema }
const { sequelize, Sequelize } = require("../db")

const roleSchema = sequelize.define("Roles", {
  id: {
    type: Sequelize.INTEGER(6),
    allowNull: false,
    primaryKey: true,
    autoIncrement: true
  },
  name: {
    type: Sequelize.STRING,
    allowNull: false
  }
}, {
  timestamps: false
})

function initial() {
  Role.create({
    id: 1,
    name: "user"
  });

  Role.create({
    id: 2,
    name: "moderator"
  });

  Role.create({
    id: 3,
    name: "admin"
  })
}

module.exports = { roleSchema }
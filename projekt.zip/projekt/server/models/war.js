const { sequelize, Sequelize } = require("../db")
const jsonfile = require("jsonfile")

const warSchema = sequelize.define("Wars", {
    id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        primaryKey: true,
        autoIncrement: true
    },
    name: {
        type: Sequelize.STRING,
        allowNull: false,
        unique: true
    },
    start: {
        type: Sequelize.INTEGER,
        allowNull: false
    },
    end: {
        type: Sequelize.INTEGER,
        allowNull: false
    }
}, {
    timestamps: false
})

let warJSON = jsonfile.readFileSync("../sql/wars.json")
async function loadWarData() {
    for (var i = 0; i < warJSON.length; i++) {
        var nameInsert = warJSON[i].name,
            startInsert = warJSON[i].start
            if (warJSON[i].end==="present"){
                endInsert = 2023
            } else {
                endInsert = warJSON[i].end
            }
            //console.log(endInsert)
            
        await warSchema.queryInterface.bulkInsert('wars', [{
            name: nameInsert,
            start: startInsert,
            end: endInsert
        }], { ignoreDuplicates: true })
    }
}
loadWarData()

module.exports = { warSchema }
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.Objects;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        try {
            String temp_url = "http://localhost/IS_LAB6_REST/cities/read/";
            URL url = new URL(temp_url);
            System.out.println("Wysyłanie zapytania...");
            InputStream is = url.openStream();
            System.out.println("Pobieranie odpowiedzi...");
            String source = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"));
            System.out.println("Przetwarzanie danych...");
            JSONObject json = new JSONObject(source);
            JSONArray recieveddata = (JSONArray) json.get("cities");
            for (Object jsonObject: recieveddata) {
                if(jsonObject instanceof JSONObject) {
                    System.out.println("City name: " + ((JSONObject) jsonObject).get("Name"));
                    System.out.println("Country code: " + ((JSONObject) jsonObject).get("CountryCode"));
                    System.out.println("District: " + ((JSONObject) jsonObject).get("District"));
                    System.out.println("Population: " + ((JSONObject) jsonObject).get("Population"));
                }
            }
        } catch (Exception e) {
            System.err.println("Wystąpił nieoczekiwany błąd !!!");
            e.printStackTrace(System.err);
        }
    }
}